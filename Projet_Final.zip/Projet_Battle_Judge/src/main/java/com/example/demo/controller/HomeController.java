package com.example.demo.controller;

import com.example.demo.AppProxy;
import com.example.demo.model.*;
import com.example.demo.model.User;
import lombok.Data;
import org.springframework.security.access.annotation.Secured;
import org.springframework.ui.Model;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping
public class HomeController {

    @Autowired
    private AppProxy proxy;

    private User getSelf(Authentication authentication){
        return proxy.getUserByMail(authentication.getName());
    }

    @GetMapping("/")
    public ModelAndView index(Authentication authentication) {
        Long idTeam = getSelf(authentication).getIdTeam();
        if(idTeam == null)
            return new ModelAndView("redirect:/rooms");
        else
            return new ModelAndView("redirect:/" + proxy.getTeam(idTeam).getIdRoom());
    }

    @GetMapping("/rooms")
    public String rooms(Authentication authentication, Model model) {
        modelRole(authentication, model);
        if(authentication.getAuthorities().iterator().next().getAuthority() == "ROLE_USER")
            model.addAttribute("rooms", proxy.getOpenRooms());
        else
            model.addAttribute("rooms", proxy.getRooms());
        model.addAttribute("idt", new IDtransfer());
        return "rooms";
    }

    @Secured({"ROLE_JUDGE", "ROLE_ADMIN"})
    @GetMapping("/creaRoom")
    public String creaRoom(Authentication authentication, Model model) {
        modelRole(authentication, model);
        model.addAttribute("room", new Room());
        return "creaRoom";
    }

    @PostMapping("/newRoom")
    @ResponseBody
    public ModelAndView newRoom(@ModelAttribute Room room){
        proxy.addRoom(new Room(room.getName(), room.getDescription(), room.getTimer()));
        return new ModelAndView("redirect:/rooms");
    }

    @GetMapping("/selectroom")
    public ModelAndView selectroom(@ModelAttribute IDtransfer idt){
        return new ModelAndView("redirect:/" + idt.getId());
    }

    private void modelRole(Authentication authentication, Model model){
        model.addAttribute("roleName", authentication.getAuthorities().iterator().next().getAuthority());
    }

    @Data
    public class IDtransfer{
        private int id;
    }
}
