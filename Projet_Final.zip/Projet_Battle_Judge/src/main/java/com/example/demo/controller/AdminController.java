package com.example.demo.controller;

import com.example.demo.AppProxy;
import com.example.demo.model.*;
import com.example.demo.model.User;
import lombok.Data;
import org.springframework.security.access.annotation.Secured;
import org.springframework.ui.Model;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping
public class AdminController {

    @Autowired
    private AppProxy proxy;

    private String message;
    private Exercise show_exercise;
    private User show_user;


    private User getSelf(Authentication authentication){
        return proxy.getUserByMail(authentication.getName());
    }

    @Secured("ROLE_ADMIN")
    @GetMapping("/admin")
    public String admin(){
        return "admin";
    }

    @Secured("ROLE_ADMIN")
    @GetMapping("/permissions")
    public String permissions(Model model) throws CloneNotSupportedException {
        model.addAttribute("User", new User());
        model.addAttribute("show_user", show_user == null ? null : show_user.copy());
        model.addAttribute("error", message);
        show_user = null;
        message = "";
        return "permissions";
    }

    @Secured("ROLE_ADMIN")
    @PostMapping("/searchuser")
    @ResponseBody
    public ModelAndView searchuser(@ModelAttribute User user){
        if(proxy.isMailExistant(user.getMail()))
            show_user = proxy.getUserByMail(user.getMail());
        else
            message = "Il n'y a pas d'utilisateur possédant cette adresse mail.";
        return new ModelAndView("redirect:/permissions");
    }

    @Secured("ROLE_ADMIN")
    @GetMapping("/rolejudge/{idUser}")
    public ModelAndView roleJudge(@PathVariable("idUser") long idUser){
        User u = proxy.getUser(idUser);
        if(u.getIdTeam() != null){
            message = "Ce joueur est actuellement en pleine partie, attendez qu'il ait fini !";
            show_user = u;
            return new ModelAndView("redirect:/permissions");
        }
        if(u.getIdRole() == 0)
            u.setIdRole(1L);
        else if(u.getIdRole() == 1)
            u.setIdRole(0L);
        proxy.addUser(u);
        show_user = u;
        return new ModelAndView("redirect:/permissions");
    }

    @Secured("ROLE_ADMIN")
    @GetMapping("/roleadmin/{idUser}")
    public ModelAndView roleAdmin(@PathVariable("idUser") long idUser){
        User u = proxy.getUser(idUser);
        if(u.getIdTeam() != null){
            message = "Ce joueur est actuellement en pleine partie, attendez qu'il ait fini !";
            show_user = u;
            return new ModelAndView("redirect:/permissions");
        }
        if(u.getIdRole() != 2)
            u.setIdRole(2L);
        else
            u.setIdRole(0L);
        proxy.addUser(u);
        show_user = u;
        return new ModelAndView("redirect:/permissions");
    }

    @Secured("ROLE_ADMIN")
    @GetMapping("/creaEx")
    public String creaEx(Model model){
        model.addAttribute("exercise", new Exercise());
        model.addAttribute("error", message);
        message = "";
        return "creaEx";
    }

    @Secured("ROLE_ADMIN")
    @PostMapping("/newExercise")
    @ResponseBody
    public ModelAndView newExercise(@ModelAttribute Exercise exercise){
        proxy.addExercise(exercise);
        message = "Votre exercice a bien été créé !";
        return new ModelAndView("redirect:/creaEx");
    }

    @Secured("ROLE_ADMIN")
    @GetMapping("/seeEx")
    public String seeEx(Model model) throws CloneNotSupportedException {
        model.addAttribute("idt", new IDtransfer());
        model.addAttribute("exercises", proxy.getExercises());
        model.addAttribute("show_exercise", show_exercise == null ? null : show_exercise.copy());
        show_exercise = null;
        return "seeEx";
    }

    @Secured("ROLE_ADMIN")
    @PostMapping("/showexercise")
    @ResponseBody
    public ModelAndView seeEx(@ModelAttribute IDtransfer idt){
        show_exercise = proxy.getExercise(idt.getId());
        return new ModelAndView("redirect:/seeEx");
    }

    @Secured("ROLE_ADMIN")
    @GetMapping("/deleteexercise/{idExercise}")
    public ModelAndView deleteExercise(@PathVariable("idExercise") long idExercise){
        proxy.deleteExercise(idExercise);
        return new ModelAndView("redirect:/seeEx");
    }

    private void modelRole(Authentication authentication, Model model){
        model.addAttribute("roleName", authentication.getAuthorities().iterator().next().getAuthority());
    }

    @Data
    public class IDtransfer{
        private int id;
    }

}
