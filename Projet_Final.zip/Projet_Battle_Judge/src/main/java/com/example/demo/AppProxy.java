package com.example.demo;

import com.example.demo.model.*;
import com.example.demo.model.User;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Date;
import java.util.Optional;

@Component
public class AppProxy {

    private static String apiURL = "http://localhost:9000";


    ////////////////////////////////////////////////////////////////////////
    ///////////////////////// GET ALL ELEMENTS /////////////////////////////
    ////////////////////////////////////////////////////////////////////////

    public Iterable<Room> getRooms(){
        String url = apiURL + "/rooms";
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Iterable<Room>> response = rt.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<Iterable<Room>>() {}
        );
        return response.getBody();
    }

    public Iterable<Answer> getAnswers(){
        String url = apiURL + "/answers";
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Iterable<Answer>> response = rt.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<Iterable<Answer>>() {}
        );
        return response.getBody();
    }

    public Iterable<Exercise> getExercises(){
        String url = apiURL + "/exercises";
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Iterable<Exercise>> response = rt.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<Iterable<Exercise>>() {}
        );
        return response.getBody();
    }

    public Iterable<Team> getTeams(){
        String url = apiURL + "/teams";
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Iterable<Team>> response = rt.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<Iterable<Team>>() {}
        );
        return response.getBody();
    }

    public Iterable<User> getUsers(){
        String url = apiURL + "/users";
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Iterable<User>> response = rt.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<Iterable<User>>() {}
        );
        return response.getBody();
    }


    ////////////////////////////////////////////////////////////////////////
    ///////////////////////// GET SINGLE ELEMENT ///////////////////////////
    ////////////////////////////////////////////////////////////////////////

    public Room getRoom(long idRoom){
        String url = apiURL + "/rooms/" + idRoom;
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Room> response = rt.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<Room>() {}
        );
        return response.getBody();
    }

    public Answer getAnswer(long idAnswer){
        String url = apiURL + "/answers/" + idAnswer;
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Answer> response = rt.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<Answer>() {}
        );
        return response.getBody();
    }

    public Exercise getExercise(long idExercise){
        String url = apiURL + "/exercises/" + idExercise;
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Exercise> response = rt.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<Exercise>() {}
        );
        return response.getBody();
    }

    public Team getTeam(long idTeam){
        String url = apiURL + "/teams/" + idTeam;
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Team> response = rt.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<Team>() {}
        );
        return response.getBody();
    }

    public User getUser(long idUser){
        String url = apiURL + "/users/" + idUser;
        RestTemplate rt = new RestTemplate();
        ResponseEntity<User> response = rt.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<User>() {}
        );
        return response.getBody();
    }

    public Rela getRela(long idRela){
        String url = apiURL + "/relas/" + idRela;
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Rela> response = rt.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<Rela>() {}
        );
        return response.getBody();
    }


    ////////////////////////////////////////////////////////////////////////
    //////////////////////////// ADD ELEMENT ///////////////////////////////
    ////////////////////////////////////////////////////////////////////////

    public Room addRoom(Room room){
        String url = apiURL + "/rooms/addRoom";
        RestTemplate rt = new RestTemplate();
        HttpEntity<Room> request = new HttpEntity<Room>(room);
        ResponseEntity<Room> response = rt.exchange(
                url,
                HttpMethod.POST,
                request,
                Room.class
        );
        return response.getBody();
    }

    public Answer addAnswer(Answer answer){
        String url = apiURL + "/answers/addAnswer";
        RestTemplate rt = new RestTemplate();
        HttpEntity<Answer> request = new HttpEntity<Answer>(answer);
        ResponseEntity<Answer> response = rt.exchange(
                url,
                HttpMethod.POST,
                request,
                Answer.class
        );
        return response.getBody();
    }

    public Exercise addExercise(Exercise exercise){
        String url = apiURL + "/exercises/addExercise";
        RestTemplate rt = new RestTemplate();
        HttpEntity<Exercise> request = new HttpEntity<Exercise>(exercise);
        ResponseEntity<Exercise> response = rt.exchange(
                url,
                HttpMethod.POST,
                request,
                Exercise.class
        );
        return response.getBody();
    }

    public Team addTeam(Team team){
        String url = apiURL + "/teams/addTeam";
        RestTemplate rt = new RestTemplate();
        HttpEntity<Team> request = new HttpEntity<Team>(team);
        ResponseEntity<Team> response = rt.exchange(
                url,
                HttpMethod.POST,
                request,
                Team.class
        );
        return response.getBody();
    }

    public User addUser(User user){
        String url = apiURL + "/users/addUser";
        RestTemplate rt = new RestTemplate();
        HttpEntity<User> request = new HttpEntity<User>(user);
        ResponseEntity<User> response = rt.exchange(
                url,
                HttpMethod.POST,
                request,
                User.class
        );
        return response.getBody();
    }

    public Rela addRela(Rela rela){
        String url = apiURL + "/relas/addRela";
        RestTemplate rt = new RestTemplate();
        HttpEntity<Rela> request = new HttpEntity<Rela>(rela);
        ResponseEntity<Rela> response = rt.exchange(
                url,
                HttpMethod.POST,
                request,
                Rela.class
        );
        return response.getBody();
    }



    ////////////////////////////////////////////////////////////////////////
    /////////////////////////// DELETE ELEMENT /////////////////////////////
    ////////////////////////////////////////////////////////////////////////

    public void deleteRoom(long idRoom){
        String url = apiURL + "/deleteRoom/" + idRoom;
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Room> response = rt.exchange(
                url,
                HttpMethod.DELETE,
                null,
                Room.class
        );
    }

    public void deleteAnswer(long idAnswer){
        String url = apiURL + "/deleteAnswer/" + idAnswer;
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Answer> response = rt.exchange(
                url,
                HttpMethod.DELETE,
                null,
                Answer.class
        );
    }

    public void deleteExercise(long idExercise){
        String url = apiURL + "/deleteExercise/" + idExercise;
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Exercise> response = rt.exchange(
                url,
                HttpMethod.DELETE,
                null,
                Exercise.class
        );
    }

    public void deleteTeam(long idTeam){
        String url = apiURL + "/deleteTeam/" + idTeam;
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Team> response = rt.exchange(
                url,
                HttpMethod.DELETE,
                null,
                Team.class
        );
    }

    public void deleteUser(long idUser){
        String url = apiURL + "/deleteUser/" + idUser;
        RestTemplate rt = new RestTemplate();
        ResponseEntity<User> response = rt.exchange(
                url,
                HttpMethod.DELETE,
                null,
                User.class
        );
    }

    public void deleteRela(long idRela){
        String url = apiURL + "/deleteRela/" + idRela;
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Rela> response = rt.exchange(
                url,
                HttpMethod.DELETE,
                null,
                Rela.class
        );
    }


    ////////////////////////////////////////////////////////////////////////
    ////////////////////////// OTHER FUNCTIONS /////////////////////////////
    ////////////////////////////////////////////////////////////////////////

    public Iterable<Team> getRoomTeams(long idRoom){
        String url = apiURL + "/roomTeams/" + idRoom;
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Iterable<Team>> response = rt.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<Iterable<Team>>() {}
        );
        return response.getBody();
    }

    public Iterable<Exercise> getRoomExercises(long idRoom){
        String url = apiURL + "/roomExercises/" + idRoom;
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Iterable<Exercise>> response = rt.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<Iterable<Exercise>>() {}
        );
        return response.getBody();
    }

    public Iterable<Answer> getRoomExerciseAnswers(long idRoom, long idExercise){
        String url = apiURL + "/roomExerciseAnswers/" + idRoom + "/" + idExercise;
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Iterable<Answer>> response = rt.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<Iterable<Answer>>() {}
        );
        return response.getBody();
    }

    public Iterable<Exercise> getRoomNotExercises(long idRoom){
        String url = apiURL + "/roomNotExercises/" + idRoom;
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Iterable<Exercise>> response = rt.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<Iterable<Exercise>>() {}
        );
        return response.getBody();
    }

    public Iterable<User> getTeamUsers(long idTeam){
        String url = apiURL + "/teamUsers/" + idTeam;
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Iterable<User>> response = rt.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<Iterable<User>>() {}
        );
        return response.getBody();
    }

    public Iterable<Room> getOpenRooms(){
        String url = apiURL + "/rooms/open";
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Iterable<Room>> response = rt.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<Iterable<Room>>() {}
        );
        return response.getBody();
    }

    public Boolean getTeamExerciseSuccess(long idTeam, long idExercise){
        String url = apiURL + "/teamSuccess/" + idExercise + "/" + idTeam;
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Boolean> response = rt.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<Boolean>() {}
        );
        return response.getBody();
    }

    public Boolean getSuccessExercise(long idRoom, long idExercise){
        String url = apiURL + "/roomSuccess/" + idRoom + "/" + idExercise;
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Boolean> response = rt.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<Boolean>() {}
        );
        return response.getBody();
    }

    public void addRoomExercise(long idRoom, long idExercise){
        String url = apiURL + "/addRoomExercise/" + idRoom + "/" + idExercise;
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Object> response = rt.exchange(
                url,
                HttpMethod.POST,
                null,
                new ParameterizedTypeReference<Object>() {}
        );
    }

    public void deleteRoomExercise(long idRoom, long idExercise){
        String url = apiURL + "/deleteRoomExercise/" + idRoom + "/" + idExercise;
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Object> response = rt.exchange(
                url,
                HttpMethod.DELETE,
                null,
                new ParameterizedTypeReference<Object>() {}
        );
    }

    public User addUserToTeam(long idUser, long idTeam){
        User user = getUser(idUser);
        user.setIdTeam(idTeam);
        return addUser(user);
    }

    public User getUserByMail(String mail){
        String url = apiURL + "/users/mail/" + mail;
        RestTemplate rt = new RestTemplate();
        ResponseEntity<User> response = rt.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<User>() {}
        );
        return response.getBody();
    }

    public Optional<User> findUserByMail(String mail){
        String url = apiURL + "/finduserbymail/" + mail;
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Optional<User>> response = rt.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<Optional<User>>() {}
        );
        return response.getBody();
    }

    public Optional<User> findUserByName(String name){
        String url = apiURL + "/finduserbyname/" + name;
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Optional<User>> response = rt.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<Optional<User>>() {}
        );
        return response.getBody();
    }

    public Optional<User> findUserByMailConnection(String mail, String password){
        String url = apiURL + "/finduserbymailconnection/" + mail + "/" + password;
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Optional<User>> response = rt.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<Optional<User>>() {}
        );
        return response.getBody();
    }

    public Boolean isExerciseInRoom(long idRoom, long idExercise){
        String url = apiURL + "/rooms/" + idRoom + "/exercise/" + idExercise;
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Boolean> response = rt.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<Boolean>() {}
        );
        return response.getBody();
    }

    public Boolean isMailExistant(String mail){
        String url = apiURL + "/users/mailexists/" + mail;
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Boolean> response = rt.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<Boolean>() {}
        );
        return response.getBody();
    }

    public Team addScore(long idTeam, long score){
        Team t = getTeam(idTeam);
        t.setScore(t.getScore() + score);
        return addTeam(t);
    }

    public Room startRoom(long idRoom){
        Room r = getRoom(idRoom);
        r.setStartTime((new Date()).getTime() / 1000);
        r.setStarted(Long.valueOf(1));
        return addRoom(r);
    }

    public Iterable<Rela> getRelaId(long idRoom, long idExercise){
        String url = apiURL + "/relasId/" + idRoom + "/" + idExercise;
        RestTemplate rt = new RestTemplate();
        ResponseEntity<Iterable<Rela>> response = rt.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<Iterable<Rela>>() {}
        );
        return response.getBody();
    }
}
