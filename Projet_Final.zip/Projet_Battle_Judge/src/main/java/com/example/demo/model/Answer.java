package com.example.demo.model;

import lombok.Data;

/**
 * Classe liée à la table answer
 */
@Data
public class Answer {

    private Long id;
    private Long idTeam;
    private Long idExercise;
    private String text;
    private Long success;

    public Answer() { }

    public Answer(Long idTeam, Long idExercise, String text, Long success){
        this.idTeam = idTeam;
        this.idExercise = idExercise;
        this.text = text;
        this.success = success;
    }

    public Answer(Long id, Long idTeam, Long idExercise, String text, Long success){
        this.id = id;
        this.idTeam = idTeam;
        this.idExercise = idExercise;
        this.text = text;
        this.success = success;
    }
}
