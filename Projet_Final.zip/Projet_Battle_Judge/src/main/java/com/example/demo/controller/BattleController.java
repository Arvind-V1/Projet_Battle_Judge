package com.example.demo.controller;

import com.example.demo.AppProxy;
import com.example.demo.model.*;
import com.example.demo.model.User;
import com.example.demo.service.UserService;
import lombok.Data;
import org.springframework.security.access.annotation.Secured;
import org.springframework.ui.Model;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;

@Controller
@RequestMapping
public class BattleController {
    @Autowired
    private AppProxy proxy;

    private final UserService userService;
    @Autowired
    public BattleController(UserService userService){
        this.userService = userService;
    }

    private String message;


    private User getSelf(Authentication authentication){
        return proxy.getUserByMail(authentication.getName());
    }

    @GetMapping("/{idRoom}/exercise/{idExercise}")
    public String exercise(@PathVariable("idRoom") long idRoom, @PathVariable("idExercise") long idExercise, Authentication authentication, Model model){
        if(proxy.getRoom(idRoom).getStarted() == 0)
            return null;
        modelRole(authentication, model);
        model.addAttribute("room", proxy.getRoom(idRoom));
        model.addAttribute("exercise", proxy.getExercise(idExercise));
        model.addAttribute("answer", new Answer());
        model.addAttribute("message", message);
        message = "";

        if(authentication.getAuthorities().iterator().next().getAuthority() != "ROLE_USER"){
            ArrayList<AnswerTeam> al = getAnswerTeam(idRoom, idExercise);
            model.addAttribute("answers", al);
        }
        return "exercise";
    }

    @PostMapping("/{idRoom}/answer/{idExercise}")
    @ResponseBody
    public ModelAndView answer(@ModelAttribute Answer answer, @PathVariable("idRoom") long idRoom, @PathVariable("idExercise") long idExercise, Authentication authentication){
        long idTeam = getSelf(authentication).getIdTeam();
        if(proxy.getTeamExerciseSuccess(idTeam, idExercise)){
            message = "Votre équipe a déjà donné la bonne réponse pour cette question !";
            return new ModelAndView("redirect:/{idRoom}/exercise/{idExercise}");
        }
        String ans = answer.getText();
        if(ans.equals(""))
            return new ModelAndView("redirect:/{idRoom}/exercise/{idExercise}");

        int bonus = 0;
        long reward = proxy.getExercise(idExercise).getReward();

        //Cas où l'équipe entre une bonne réponse (sans compter les majuscules)
        if(ans.toLowerCase().equals(proxy.getExercise(idExercise).getAnswer().toLowerCase())){
            message = "Bonne réponse !";
            if(!proxy.getSuccessExercise(idRoom, idExercise)) {
                bonus = (int) (reward * 0.2);
                message += " Vous gagnez " + bonus + " points bonus car vous êtes la première équipe à trouver la réponse !";
            }
            proxy.addScore(idTeam, reward + bonus);
            proxy.addAnswer(new Answer(idTeam, idExercise, ans, 1L));
            return new ModelAndView("redirect:/{idRoom}/exercise/{idExercise}");
        }
        //Cas où l'équipe entre une mauvaise réponse
        else {
            bonus = (int) (reward * -0.2);
            message = "Mauvaise réponse...\n Vous écopez de " + (-bonus) + " point" + (reward > 1 ? "s" : "") + " de pénalité.";
            proxy.addScore(idTeam, bonus);
            proxy.addAnswer(new Answer(idTeam, idExercise, ans, 0L));
        }
        return new ModelAndView("redirect:/{idRoom}/exercise/{idExercise}");
    }

    @Secured({"ROLE_JUDGE", "ROLE_ADMIN"})
    @GetMapping("/{idRoom}/downscore/{idTeam}")
    public ModelAndView downscore(@PathVariable("idRoom") long idRoom, @PathVariable("idTeam") long idTeam){
        Team t = proxy.getTeam(idTeam);
        t.setScore(t.getScore() - 1);
        proxy.addTeam(t);
        return new ModelAndView("redirect:/{idRoom}");
    }

    @Secured({"ROLE_JUDGE", "ROLE_ADMIN"})
    @GetMapping("/{idRoom}/upscore/{idTeam}")
    public ModelAndView upscore(@PathVariable("idRoom") long idRoom, @PathVariable("idTeam") long idTeam){
        Team t = proxy.getTeam(idTeam);
        t.setScore(t.getScore() + 1);
        proxy.addTeam(t);
        return new ModelAndView("redirect:/{idRoom}");
    }

    @GetMapping("/giveup")
    public ModelAndView giveUp(Authentication authentication){
        User u = getSelf(authentication);
        u.setIdTeam(null);
        proxy.addUser(u);
        return new ModelAndView("redirect:/rooms");
    }

    private void modelRole(Authentication authentication, Model model){
        model.addAttribute("roleName", authentication.getAuthorities().iterator().next().getAuthority());
    }

    @Data
    public class AnswerTeam{
        private Answer answer;
        private Team team;

        public AnswerTeam(){}

        public AnswerTeam(Answer answer, Team team){
            this.answer = answer;
            this.team = team;
        }
    }

    private ArrayList<AnswerTeam> getAnswerTeam(long idRoom, long idExercise){
        ArrayList<AnswerTeam> al = new ArrayList<AnswerTeam>();
        Iterable<Answer> answers = proxy.getRoomExerciseAnswers(idRoom, idExercise);
        for(Answer a : answers)
            al.add(new AnswerTeam(a, proxy.getTeam(a.getIdTeam())));
        return al;
    }
}
