package com.example.demo.controller;

import com.example.demo.AppProxy;
import com.example.demo.model.User;
import com.example.demo.service.UserService;
import org.springframework.ui.Model;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping
public class LoginController {

    @Autowired
    private AppProxy proxy;
    private final UserService userService;
    @Autowired
    public LoginController(UserService userService){
        this.userService = userService;
    }

    @GetMapping("/login")
    public String login(Model model){
        return "login";
    }

    @GetMapping("/register")
    public String register(Model model){
        User user = new User();
        model.addAttribute("user",user);
        return "register";
    }

    @PostMapping("/register")
    public String registerNewUser(@ModelAttribute("user") User user){

        try{
            userService.addNewUser(user);
            return "login";
        }
        catch (Exception e){
            return "register";
        }
    }
}
