package com.example.demo.controller;

import com.example.demo.AppProxy;
import com.example.demo.model.*;
import com.example.demo.model.User;
import lombok.Data;
import org.springframework.security.access.annotation.Secured;
import org.springframework.ui.Model;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Date;

@Controller
@RequestMapping
public class RoomController {

    @Autowired
    private AppProxy proxy;
    private TeamTransfer players = new TeamTransfer();
    private Exercise show_exercise;

    private User getSelf(Authentication authentication){
        return proxy.getUserByMail(authentication.getName());
    }

    @GetMapping("/{idRoom}")
    public String teams(Authentication authentication, Model model, @PathVariable("idRoom") int idRoom) throws CloneNotSupportedException {
        modelRole(authentication, model);
        Room r = proxy.getRoom(idRoom);
        model.addAttribute("room", r);

        Long idTeam = getSelf(authentication).getIdTeam();
        if(r.getStarted().intValue() == 0){
            if(authentication.getAuthorities().iterator().next().getAuthority() == "ROLE_USER") {
                if (idTeam == null){
                    modelRole(authentication, model);
                    model.addAttribute("teams", proxy.getRoomTeams(idRoom));
                    model.addAttribute("players", players.copy());
                    model.addAttribute("team", new Team());
                    players.clear();
                    return "teams";
                }
                else {
                    model.addAttribute("players", new TeamTransfer(proxy.getTeam(idTeam), proxy.getTeamUsers(idTeam)));
                    model.addAttribute("teams", new ArrayList<>());
                    return "waiting";
                }
            }
            else{
                Iterable<Team> teams = proxy.getRoomTeams(idRoom);
                ArrayList<TeamTransfer> al = new ArrayList<TeamTransfer>();
                for(Team t : teams)
                    al.add(new TeamTransfer(t, proxy.getTeamUsers(t.getId())));
                model.addAttribute("teams", al);
                return "waiting";
            }
        }
        else{
            boolean end = false;
            Iterable<Team> teams = proxy.getRoomTeams(idRoom);
            model.addAttribute("teams", teams);
            long remaining = r.getTimer() - ((new Date()).getTime() / 1000) + r.getStartTime();
            model.addAttribute("timer2",remaining );
            String timer;
            String win = "";
            ArrayList<Team> winners = new ArrayList<Team>();
            if(remaining <= 0) {
                timer = "La partie est terminée !";
                end = true;
                for(Team t : teams){
                    if(winners.isEmpty() || winners.get(0).getScore() < t.getScore()){
                        winners.clear();
                        winners.add(t);
                    }
                    else if(winners.get(0).getScore() == t.getScore())
                        winners.add(t);
                }
                if(winners.size() == 1)
                    win = "L'équipe \"" + winners.get(0).getName() + "\" remporte la partie !";
                else{
                    win = "Les équipes ";
                    for(Team t : winners){
                        win += "\"" + t.getName() + "\", ";
                    }
                    win = win.substring(0, win.length() - 2);
                    win += " remportent la partie !";
                }
                model.addAttribute("win", win);
            }
            else {
                long hours = remaining / 3600;
                if(hours != 0)
                    remaining -= (3600 * hours);
                long minutes = remaining / 60;
                if(minutes != 0)
                    remaining -= (60 * minutes);
                timer = "Temps restant : " + hours + "h " + minutes + "m " + remaining + "s";
            }
            model.addAttribute("timer", timer);
            model.addAttribute("end", end);

            if(authentication.getAuthorities().iterator().next().getAuthority() != "ROLE_USER") {
                model.addAttribute("exercises", proxy.getRoomExercises(idRoom));
                return "battle";
            }
            if (idTeam == null){
                return null;
            }
            else {
                Iterable<Exercise> e = proxy.getRoomExercises(idRoom);
                ArrayList<ExerciseTeam> al = new ArrayList<ExerciseTeam>();
                for(Exercise ex : e)
                    al.add(new ExerciseTeam(ex, proxy.getTeamExerciseSuccess(idTeam, ex.getId())));
                model.addAttribute("exercises", al);
                model.addAttribute("team", proxy.getTeam(idTeam));
                return "battle";
            }
        }
    }

    @PostMapping("/{idRoom}/newTeam")
    @ResponseBody
    public ModelAndView newTeam(@ModelAttribute Team team, @PathVariable("idRoom") long idRoom){
        team.setScore(0L);
        team.setIdRoom(idRoom);
        Team t = proxy.addTeam(team);
        return new ModelAndView("redirect:/{idRoom}/jointeam/" + t.getId());
    }

    @Secured({"ROLE_JUDGE", "ROLE_ADMIN"})
    @GetMapping("/{idRoom}/manage")
    public String manage(Authentication authentication, Model model, @PathVariable("idRoom") long idRoom) throws CloneNotSupportedException {
        modelRole(authentication, model);
        model.addAttribute("idt", new IDtransfer());
        model.addAttribute("exercises", proxy.getRoomNotExercises(idRoom));
        model.addAttribute("roomexercises", proxy.getRoomExercises(idRoom));
        model.addAttribute("room", proxy.getRoom(idRoom));
        if(show_exercise != null){
            if(proxy.isExerciseInRoom(idRoom, show_exercise.getId())) {
                model.addAttribute("show_exercise", null);
                model.addAttribute("show_exercise2", show_exercise.copy());
            }
            else{
                model.addAttribute("show_exercise", show_exercise.copy());
                model.addAttribute("show_exercise2", null);
            }
        }
        show_exercise = null;
        return "manageRoom";
    }

    @Secured({"ROLE_JUDGE", "ROLE_ADMIN"})
    @PostMapping("/{idRoom}/showexercise")
    public ModelAndView showExercise(@ModelAttribute IDtransfer idt, @PathVariable("idRoom") long idRoom){
        show_exercise = proxy.getExercise(idt.getId());
        return new ModelAndView("redirect:/{idRoom}/manage");
    }

    @Secured({"ROLE_JUDGE", "ROLE_ADMIN"})
    @GetMapping("/{idRoom}/addexercise/{idExercise}")
    public ModelAndView addExercise(@PathVariable("idRoom") long idRoom, @PathVariable("idExercise") long idExercise){
        proxy.addRela(new Rela(idRoom, idExercise));
        return new ModelAndView("redirect:/{idRoom}/manage");
    }

    @Secured({"ROLE_JUDGE", "ROLE_ADMIN"})
    @GetMapping("/{idRoom}/removeexercise/{idExercise}")
    public ModelAndView removeExercise(@PathVariable("idRoom") long idRoom, @PathVariable("idExercise") long idExercise){
        proxy.deleteRela(proxy.getRelaId(idRoom, idExercise).iterator().next().getId());
        return new ModelAndView("redirect:/{idRoom}/manage");
    }

    @GetMapping("/{idRoom}/list/{idTeam}")
    public ModelAndView showTeam(@PathVariable("idRoom") long idRoom, @PathVariable("idTeam") long idTeam){
        players.setTeam(proxy.getTeam(idTeam));
        players.setMembers(proxy.getTeamUsers(idTeam));
        return new ModelAndView("redirect:/{idRoom}");
    }

    @GetMapping("/{idRoom}/jointeam/{idTeam}")
    public ModelAndView joinTeam(@PathVariable("idRoom") long idRoom, @PathVariable("idTeam") long idTeam, Authentication authentication){
        if(authentication.getAuthorities().iterator().next().getAuthority() == "ROLE_USER")
            proxy.addUserToTeam(getSelf(authentication).getId(), idTeam);
        return new ModelAndView("redirect:/{idRoom}");
    }

    @GetMapping("/{idRoom}/leaveteam")
    public ModelAndView leaveTeam(@PathVariable("idRoom") long idRoom, Authentication authentication){
        User u = getSelf(authentication);
        Iterator<User> it = proxy.getTeamUsers(u.getIdTeam()).iterator();
        it.next();
        if(!it.hasNext())
            proxy.deleteTeam(u.getIdTeam());
        else{
            u.setIdTeam(null);
            proxy.addUser(u);
        }
        return new ModelAndView("redirect:/{idRoom}");
    }

    @Secured({"ROLE_JUDGE", "ROLE_ADMIN"})
    @GetMapping("/{idRoom}/start")
    public ModelAndView startRoom(@PathVariable("idRoom") long idRoom){
        proxy.startRoom(idRoom);
        return new ModelAndView("redirect:/{idRoom}");
    }

    @Secured({"ROLE_JUDGE", "ROLE_ADMIN"})
    @GetMapping("/{idRoom}/delete")
    public ModelAndView deleteRoom(@PathVariable("idRoom") long idRoom){
        proxy.deleteRoom(idRoom);
        return new ModelAndView("redirect:/rooms");
    }

    private void modelRole(Authentication authentication, Model model){
        model.addAttribute("roleName", authentication.getAuthorities().iterator().next().getAuthority());
    }





    @Data
    public class IDtransfer{
        private int id;
    }

    @Data
    public class TeamTransfer implements Cloneable{
        private Team team;
        private Iterable<User> members;
        public TeamTransfer(){
            this.team = new Team();
            this.members = new ArrayList<User>();
        }

        public TeamTransfer(Team team, Iterable<User> members){
            this.team = team;
            this.members = members;
        }

        public TeamTransfer copy() throws CloneNotSupportedException {
            return (TeamTransfer) this.clone();
        }

        public void clear(){
            this.members = new ArrayList<User>();
        }
    }

    @Data
    public class ExerciseTeam{
        private Exercise exercise;
        private boolean succeed;

        public ExerciseTeam(Exercise exercise, boolean succeed){
            this.exercise = exercise;
            this.succeed = succeed;
        }
    }
}