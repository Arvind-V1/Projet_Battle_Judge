package com.example.demo.model;

import lombok.Data;

/**
 * Classe liée à la table team
 */
@Data
public class Team {

    private Long id;
    private String name;
    private Long score;
    private Long idRoom;

    public Team() { }

    public Team(Long id, String name, Long score, Long idRoom){
        this.id = id;
        this.name = name;
        this.score = score;
        this.idRoom = idRoom;
    }

}
