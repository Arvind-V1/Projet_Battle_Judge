package com.example.demo.model;

import lombok.Data;

/**
 * Classe liée à la table room
 */
@Data
public class Room {

    private Long id;
    private String name;
    private String description;
    private Long timer;
    private Long started;
    private Long startTime;

    public Room() { }

    public Room(String name, String description, Long timer){
        this.name = name;
        this.description = description;
        this.timer = timer;
        this.started = 0L;
        this.startTime = 0L;
    }
}
