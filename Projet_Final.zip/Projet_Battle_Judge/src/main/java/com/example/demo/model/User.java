package com.example.demo.model;

import jakarta.persistence.*;

import lombok.Data;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.security.SecureRandom;
import java.util.Collection;
import java.util.Collections;

@Data
public class User implements UserDetails, Cloneable{
    @Id
    @SequenceGenerator(
            name = "user_sequence",
            sequenceName = "user_sequence",
            allocationSize = 2
    )
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "user_sequence"
    )
    private Long id;
    private String mail;
    private String name;
    private String password;
    // 0 = User / 1 = Judge / 2 = Admin
    private Long idRole;
    private Long idTeam;

    static BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();


    @Override
    public Collection<? extends GrantedAuthority> getAuthorities(){
        String role;
        if(idRole == 0)
            role = "ROLE_USER";
        else if(idRole == 1)
            role = "ROLE_JUDGE";
        else
            role = "ROLE_ADMIN";
        SimpleGrantedAuthority authority =
                new SimpleGrantedAuthority(role);
        return Collections.singletonList(authority);
    }

    @Override
    public String getUsername(){
        return mail;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    public User(long id, String name, long idTeam){
        this.id = id;
        this.name = name;
        this.idTeam = idTeam;
    }

    public User(String name, String mail, String password) {
        this.name = name;
        this.mail = mail;
        this.password = password;
        this.idRole = 0L;
    }

    public User(Long id, String name, String mail, String password) {
        this.id = id;
        this.name = name;
        this.mail = mail;
        this.password = password;
        this.idRole = 0L;
    }

    public User(String name, String mail, String password, Long idRole) {
        this.name = name;
        this.mail = mail;
        this.password = password;
        this.idRole = idRole;
    }

    public User(){
        this.idRole = 0L;
    }

    public User(Long id, Long idTeam, String name, String mail, String password, Long idRole) {
        this.id = id;
        this.idTeam = idTeam;
        this.name = name;
        this.mail = mail;
        this.password = password;
        this.idRole = 0L;
    }

    @Override
    public String toString() {
        String role;
        if(idRole == 0)
            role = "User";
        else if(idRole == 1)
            role = "Judge";
        else
            role = "Admin";

        return "User{" +
                "id=" + id +
                ", idTeam=" + idTeam +
                ", name='" + name + '\'' +
                ", mail='" + mail + '\'' +
                ", password='" + password + '\'' +
                ", role=" + role +
                '}';
    }

    public void encode(){
        password = encoder.encode(password);
    }

    public User copy() throws CloneNotSupportedException {
        return (User) this.clone();
    }
}


