package com.example.demo.model;

import lombok.Data;

/**
 * Classe liée à la table exercise
 */
@Data
public class Exercise implements Cloneable{

    private Long id;
    private String title;
    private String text;
    private String answer;
    private Long reward;

    public Exercise() {}

    public Exercise(Long id, String title, String text, String answer, Long reward){
        this.id = id;
        this.title = title;
        this.text = text;
        this.answer = answer;
        this.reward = reward;
    }

    public Exercise copy() throws CloneNotSupportedException {
        return (Exercise) this.clone();
    }

}
