package com.example.demo.service;


import com.example.demo.AppProxy;
import com.example.demo.model.User;
import com.example.demo.security.PasswordEncoder;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;


import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@AllArgsConstructor
@Service
@Slf4j
public class UserService implements UserDetailsService {

    @Autowired
    private AppProxy proxy;

    @Autowired
    static BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    private final static String USER_NOT_FOUND_MSG =
            "user with email %s not found";
    public Iterable<User> getUsers(){
        return proxy.getUsers();
    }

    public void addNewUser(User user) {
        Optional<User> userOptional = proxy.findUserByMail(user.getMail());
        if(userOptional.isPresent()){
            throw new IllegalStateException("Mail taken");
        }

        userOptional = proxy.findUserByName(user.getName());
        if(userOptional.isPresent()){
            throw new IllegalStateException("Name taken");
        }
        user.encode();
        proxy.addUser(user);
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        User user = proxy.findUserByMail(username)
                .orElseThrow(() ->
                        new UsernameNotFoundException(
                                String.format(USER_NOT_FOUND_MSG, username)));

        System.out.println("loadUserByUsername " + user.getPassword());

        log.info(user.toString());

        // Set the user's authorities based on their role
        String role;
        if(user.getIdRole() == 0)
            role = "ROLE_USER";
        else if(user.getIdRole() == 1)
            role = "ROLE_JUDGE";
        else
            role = "ROLE_ADMIN";

        List<GrantedAuthority> authorities = new ArrayList<>();
        authorities.add(new SimpleGrantedAuthority(role));

        return new org.springframework.security.core.userdetails.User(
                user.getMail(),
                user.getPassword(),
                authorities);
    }

}
