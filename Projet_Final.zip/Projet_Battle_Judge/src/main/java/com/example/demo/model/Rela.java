package com.example.demo.model;

import lombok.Data;

@Data
public class Rela {

    private Long id;
    private Long idExercise;
    private Long idRoom;

    public Rela() {}

    public Rela(long idRoom, long idExercise){
        this.idRoom = idRoom;
        this.idExercise = idExercise;
    }
}
