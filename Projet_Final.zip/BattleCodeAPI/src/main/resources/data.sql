drop table if exists users;
drop table if exists role;
drop table if exists relaExerciseRoom;
drop table if exists resultTeamExercise;
drop table if exists answer;
drop table if exists exercise;
drop table if exists team;
drop table if exists room;


create table role(
	id int primary key,
	title text
);

create table room(
	id int auto_increment primary key not null,
	name text not null,
	description text not null,
	timer int,
	started int not NULL
);

create table exercise(
	id int auto_increment primary key not null,
	title text not null,
	text text not null,
	answer text not null,
	reward int not null
);

create table team(
	id int auto_increment primary key not null,
	name text not null,
	score int not null,
	idRoom int not null,
	constraint `fk_idRoomTeam` foreign key (`idRoom`) references `room`(`id`) on update cascade on delete cascade
);

CREATE TABLE users(
  id INT AUTO_INCREMENT  PRIMARY KEY not null,
  mail text not null,
  name text not null,
  password text not null,
  idRole int NOT NULL,
  idTeam int,
  constraint `fk_idRoleUser` foreign key (`idRole`) references `role`(`id`) on update cascade on delete cascade,
  constraint `fk_idTeamUser` foreign key (`idTeam`) references `team`(`id`) on update cascade on delete set null
);

create table relaExerciseRoom(
	id int auto_increment primary key not null,
	idExercise int not null,
	idRoom int not null,
	constraint `fk_idExerciseRela` foreign key (`idExercise`) references `exercise`(`id`) on update cascade on delete cascade,
	constraint `fk_idRoomRela` foreign key (`idRoom`) references `room`(`id`) on update cascade on delete cascade
);

create table answer(
	id int auto_increment primary key not null,
	idTeam int not null,
	idExercise int not null,
	text text not null,
	success int not null,
	constraint `fk_idTeamAnswer` foreign key (`idTeam`) references `team`(`id`) on update cascade on delete cascade,
	constraint `fk_idExerciseAnswer` foreign key (`idExercise`) references `exercise`(`id`) on update cascade on delete cascade
);


insert into role (id, title) VALUES
	("0","user"),
	("1","judge"),
	("2","admin");

insert into room (name, description, timer, started, starttime) VALUES
	("la salle","c'est une salle", 50, "0", "0"),
	("la room", "c'est une room", 200, "0", "0"),
	("la pièce", "c'est une pièce", 2000, "1", "0");

insert into team (name, score, idroom) VALUES
    ("la tchime du sud", "0", "1"),
    ("ekip", "0", "1"),
    ("les goomboss", "0", "2");
	
INSERT INTO users (mail, name, password, idrole) VALUES
  ('u@u', 'user', '$2a$10$0ajECF3BEUIDKQ/qGcVlGuUl40lbc3Ry4ZoGLVDTQGWgaO8czRV32', '0'),
  ('u2@u2', 'user2', '$2a$10$lE5gJZq7EKFeYakLTzKYbumZTSjQswyzkjDWaKVV/Dt2.h1FnzusG', '0'),
  ('u3@u3', 'user3', '$2a$10$0OAcYoXBt31eYldwGlYRne2hTYQQ1UbSLRaWneQlqCufL6ONJaDD6', '0'),
  ('j@j', 'judge', '$2a$10$s4Hw13bGNoXiPqAb8Gen5e6kSJE6z3A5VaCTgGuAW1pux1tYNL9sa', '1'),
  ('a@a', 'admin', '$2a$10$qTWkG7U.YNJhF/VS8VWJy.PjKBXoQ6ebyDDJldvu7y0ytvpByP/5y', '2');

INSERT INTO users (mail, name, password, idrole, idteam) VALUES
  ('d', 'Denis', 'd', '0', '1'),
  ('gsserysxdg', 'René', 'rtyhdr', '0', '1'),
  ('sdgs3', 'Therry', 'rdrhd', '0', '2'),
  ('sdrzqrcgsdh', 'Eva', 'drthd', '0', '2'),
  ('sdqcrrgs', 'Florence', 'drhd', '0', '3'),
  ('srgtsevt', 'Thierry', 'yz', '0', '1'),
  ('sdrgsztvse', 'Elia', 'uevt', '0', '1'),
  ('sdrqzrgsd', 'Jean', 'veu3', '0', '2'),
  ('sdrgqsvetrvqs', 'Adrien', 'jsevt', '0', '2'),
  ('sdhsd', 'Patrick', 'aesvt', '0', '1');

insert into exercise (title, text, answer, reward) VALUES
	("facile", "blabla c'est une exo facile trkl", "answer", "5"),
	("exo2", "sqdqgfqsikjklHDQSGBDJqdhhnjknhkqdsf", "150", "10"),
	("exercice difficile", "en vrai la c'est chaud", "VBcx!!ù%21aZ", "20"),
	("La réponse", "Quelle est la réponse à la vie à l'univers et à tout le reste ?", "42", "50");

insert into relaexerciseroom (idExercise, idRoom) VALUES
	("1","1"),
	("1","2"),
	("2","2"),
	("2","3"),
	("3","1"),
	("3","3"),
	("4","2");
	
insert into answer (idTeam, idExercise, text, success) VALUES
	("1","1","réponse","0"),
	("1","3","jsp","0"),
	("2","1","answer","1"),
	("2","3","cdur","0"),
	("3","1","answer","1"),
	("3","2","150","1"),
	("3","4","42","1");


select * from role;
select * from users;
select * from team;
select * from exercise;
select * from room;
select * from relaExerciseRoom;
select * from answer;





--select users.id, users.mail, role.title from users inner join role on idrole = role.id;
--select room.name,exercise.title from room inner join relaexerciseroom on idroom = room.id inner join exercise on idexercise = exercise.id order by room.id;
--select room.id,room.name,room.description,room.started where started = 1;
--select count(*) from answer WHERE idTeam=? and idExercise=? and success=1;
--select count(*) from answer inner join team on idteam = team.id inner join room on idroom = room.id where room.id = 1 and idExercise = 1 and success = 1;
