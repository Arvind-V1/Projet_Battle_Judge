package com.esiee.BattleCodeAPI.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.esiee.BattleCodeAPI.model.Room;

@Repository
public interface RoomRepository extends CrudRepository<Room, Long> {
	
	@Query(value = "select room.id,room.name,room.description,room.timer,room.started,room.starttime from room where started = 0", nativeQuery = true)
	public Iterable<Room> getOpenRooms();

	@Query(value = "select count(*) from relaexerciseroom WHERE idRoom = :idRoom and idExercise = :idExercise", nativeQuery = true)
	public int isExerciseInRoom(@Param("idRoom") long idRoom, @Param("idExercise") long idExercise);
	
	@Query(value = "insert into relaExerciseRoom (idExercise, idRoom) VALUES(:idExercise, :idRoom)", nativeQuery = true)
	public void addRoomExercise(@Param("idRoom") long idRoom, @Param("idExercise") long idExercise);
	
	@Query(value = "delete from relaExerciseRoom where idRoom=:idRoom and idExercise=:idExercise", nativeQuery = true)
	public void deleteRoomExercise(@Param("idRoom") long idRoom, @Param("idExercise") long idExercise);
	
}
