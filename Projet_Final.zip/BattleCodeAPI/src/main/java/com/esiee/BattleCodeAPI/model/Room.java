package com.esiee.BattleCodeAPI.model;

import jakarta.persistence.*;

import lombok.Data;

@Data
@Entity
@Table(name = "room")
public class Room {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private String name;
	
	private String description;
	
	private Long timer;
	
	// 1 = on / 0 = off
	private Long started;

	@Column(name="starttime")
	private Long startTime;
}
