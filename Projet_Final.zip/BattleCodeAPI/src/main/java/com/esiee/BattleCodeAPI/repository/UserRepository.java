package com.esiee.BattleCodeAPI.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.esiee.BattleCodeAPI.model.User;

import java.util.Optional;

@Repository
public interface UserRepository extends CrudRepository<User, Long> {
	
	@Query(value = "select * from users where idTeam = :idTeam", nativeQuery = true)
	public Iterable<User> getTeamUsers(@Param("idTeam") long idTeam);

	@Query(value = "select * from users where mail = :mail", nativeQuery = true)
	public Iterable<User> getUserByMail(@Param("mail") String mail);

	@Query(value = "select count(*) from users where mail = :mail", nativeQuery = true)
	public int isMailExistant(@Param("mail") String mail);

	@Query(value = "SELECT * FROM users WHERE mail = :mail", nativeQuery = true)
	public Optional<User> findUserByMail(@Param("mail") String mail);

	@Query(value = "SELECT * FROM users WHERE name = :name", nativeQuery = true)
	public Optional<User> findUserByName(@Param("name") String name);

	@Query(value = "SELECT * FROM users WHERE mail = :mail AND password = :password", nativeQuery = true)
	public Optional<User> findUserByMailConnection(@Param("mail") String mail, @Param("password") String password);
	
}
