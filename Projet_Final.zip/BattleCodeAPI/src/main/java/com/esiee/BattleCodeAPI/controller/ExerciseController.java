package com.esiee.BattleCodeAPI.controller;

import java.util.Optional;

import com.esiee.BattleCodeAPI.model.Team;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.esiee.BattleCodeAPI.model.Exercise;
import com.esiee.BattleCodeAPI.service.ExerciseService;

@RestController
public class ExerciseController {

    @Autowired
    private ExerciseService exerciseService;

    /**
    * Read - Get all exercises
    * @return - An Iterable object of Exercise full filled
    */
    @GetMapping("/exercises")
    public Iterable<Exercise> getExercises() {
        return exerciseService.getExercises();
    }
	
	@GetMapping("/exercises/{id}")
	public Optional<Exercise> getExercise(@PathVariable long id){
		return exerciseService.getExercise(id);
	}

	@PostMapping("/exercises/addExercise")
	public Exercise saveExercise(@RequestBody Exercise exercise){
		return exerciseService.saveExercise(exercise);
	}
	
	@GetMapping("/roomExercises/{idRoom}")
	public Iterable<Exercise> getRoomExercises(@PathVariable long idRoom){
		return exerciseService.getRoomExercises(idRoom);
	}
	
	@GetMapping("/roomNotExercises/{idRoom}")
	public Iterable<Exercise> getRoomNotExercises(@PathVariable long idRoom){
		return exerciseService.getRoomNotExercises(idRoom);
	}
	
	@DeleteMapping("/deleteExercise/{id}")
	public void deleteExercise(@PathVariable long id){
		exerciseService.deleteExercise(id);
	}

}
