package com.esiee.BattleCodeAPI.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.esiee.BattleCodeAPI.model.Room;
import com.esiee.BattleCodeAPI.repository.RoomRepository;

import lombok.Data;

@Data
@Service
public class RoomService {

    @Autowired
    private RoomRepository roomRepository;

    public Optional<Room> getRoom(final Long id) {
        return roomRepository.findById(id);
    }

    public Iterable<Room> getRooms() {
        return roomRepository.findAll();
    }

    public void deleteRoom(final Long id) {
        roomRepository.deleteById(id);
    }
	
	public void deleteRoomExercise(final long idRoom, final long idExercise){
		roomRepository.deleteRoomExercise(idRoom, idExercise);
	}

    public Room saveRoom(Room room) {
        Room savedRoom = roomRepository.save(room);
        return savedRoom;
    }
	
	public void addRoomExercise(final Long idRoom, final Long idExercise){
		roomRepository.addRoomExercise(idRoom, idExercise);
	}
	
	public Iterable<Room> getOpenRooms(){
		return roomRepository.getOpenRooms();
	}

    public Boolean isExerciseInRoom(final Long idRoom, final Long idExercise){
        return roomRepository.isExerciseInRoom(idRoom, idExercise) != 0;
    }

}
