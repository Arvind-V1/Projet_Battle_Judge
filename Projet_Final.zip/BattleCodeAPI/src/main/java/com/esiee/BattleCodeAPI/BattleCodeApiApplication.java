package com.esiee.BattleCodeAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BattleCodeApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BattleCodeApiApplication.class, args);
	}

}
