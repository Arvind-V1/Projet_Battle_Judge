package com.esiee.BattleCodeAPI.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.esiee.BattleCodeAPI.model.Team;
import com.esiee.BattleCodeAPI.service.TeamService;

@RestController
public class TeamController {

    @Autowired
    private TeamService teamService;

    /**
    * Read - Get all teams
    * @return - An Iterable object of Team full filled
    */
    @GetMapping("/teams")
    public Iterable<Team> getTeams() {
        return teamService.getTeams();
    }
	
	@GetMapping("/teams/{id}")
	public Optional<Team> getTeam(@PathVariable long id){
		return teamService.getTeam(id);
	}
	
	@PostMapping("/teams/addTeam")
	public Team saveTeam(@RequestBody Team team){
		return teamService.saveTeam(team);
	}
	
	@GetMapping("/roomTeams/{idRoom}")
	public Iterable<Team> getRoomTeams(@PathVariable long idRoom){
		return teamService.getRoomTeams(idRoom);
	}
	
	@DeleteMapping("/deleteTeam/{id}")
	public void deleteTeam(@PathVariable long id){
		teamService.deleteTeam(id);
	}
}
