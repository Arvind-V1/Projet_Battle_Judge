package com.esiee.BattleCodeAPI.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.esiee.BattleCodeAPI.model.Answer;

@Repository
public interface AnswerRepository extends CrudRepository<Answer, Long> {
	
	@Query(value = "select count(*) from answer WHERE idTeam = :idTeam and idExercise = :idExercise and success=1", nativeQuery = true)
	public int getSuccessTeamExercise(@Param("idTeam") long idTeam, @Param("idExercise") long idExercise);
	
	@Query(value = "select count(*) from answer inner join team on idteam = team.id inner join room on idroom = room.id where room.id = :idRoom and idExercise = :idExercise and success = 1;", nativeQuery = true)
	public int getSuccessExercise(@Param("idExercise") long idExercise, @Param("idRoom") long idRoom);
	
	@Query(value = "select answer.id,idTeam,idExercise,text,success from answer inner join team on idteam = team.id inner join room on idroom = room.id where room.id = :idRoom and idExercise = :idExercise", nativeQuery = true)
	public Iterable<Answer> getRoomExerciseAnswers(@Param("idRoom") long idRoom, @Param("idExercise") long idExercise);
}
