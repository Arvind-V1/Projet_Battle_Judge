package com.esiee.BattleCodeAPI.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


import com.esiee.BattleCodeAPI.model.Team;

@Repository
public interface TeamRepository extends CrudRepository<Team, Long> {
	
	@Query(value = "SELECT team.id,team.name,team.score,team.idroom FROM team inner join room on room.id = idRoom where idRoom = :idRoom", nativeQuery = true)
	public Iterable<Team> getRoomTeams(@Param("idRoom") long idRoom);
}
