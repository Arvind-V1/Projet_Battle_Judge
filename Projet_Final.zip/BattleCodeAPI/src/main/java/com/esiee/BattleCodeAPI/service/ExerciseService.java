package com.esiee.BattleCodeAPI.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.esiee.BattleCodeAPI.model.Exercise;
import com.esiee.BattleCodeAPI.repository.ExerciseRepository;

import lombok.Data;

@Data
@Service
public class ExerciseService {

    @Autowired
    private ExerciseRepository exerciseRepository;

    public Optional<Exercise> getExercise(final Long id) {
        return exerciseRepository.findById(id);
    }

    public Iterable<Exercise> getExercises() {
        return exerciseRepository.findAll();
    }

    public void deleteExercise(final Long id) {
        exerciseRepository.deleteById(id);
    }

    public Exercise saveExercise(Exercise exercise) {
        Exercise savedExercise = exerciseRepository.save(exercise);
        return savedExercise;
    }
	
	public Iterable<Exercise> getRoomExercises(final long idRoom){
		return exerciseRepository.getRoomExercises(idRoom);
	}
	
	public Iterable<Exercise> getRoomNotExercises(final long idRoom){
		return exerciseRepository.getRoomNotExercises(idRoom);
	}

}
