package com.esiee.BattleCodeAPI.controller;

import java.util.Optional;

import com.esiee.BattleCodeAPI.model.Team;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.esiee.BattleCodeAPI.model.Rela;
import com.esiee.BattleCodeAPI.service.RelaService;

@RestController
public class RelaController {

    @Autowired
    private RelaService relaService;

    /**
    * Read - Get all relas
    * @return - An Iterable object of Rela full filled
    */
    @GetMapping("/relas")
    public Iterable<Rela> getRelas() {
        return relaService.getRelas();
    }
	
	@GetMapping("/relas/{id}")
	public Optional<Rela> getRela(@PathVariable long id){
		return relaService.getRela(id);
	}
	
	@GetMapping("/relasId/{idRoom}/{idExercise}")
	public Iterable<Rela> getRelaId(@PathVariable long idRoom, @PathVariable long idExercise){
		return relaService.getRelaId(idRoom, idExercise);
	}

	@PostMapping("/relas/addRela")
	public Rela saveRela(@RequestBody Rela rela){
		return relaService.saveRela(rela);
	}
	
	@DeleteMapping("/deleteRela/{id}")
	public void deleteRela(@PathVariable long id){
		relaService.deleteById(id);
	}

}
