package com.esiee.BattleCodeAPI.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.esiee.BattleCodeAPI.model.Answer;
import com.esiee.BattleCodeAPI.service.AnswerService;

@RestController
public class AnswerController {

    @Autowired
    private AnswerService answerService;

    /**
    * Read - Get all answers
    * @return - An Iterable object of Answer full filled
    */
    @GetMapping("/answers")
    public Iterable<Answer> getAnswers() {
        return answerService.getAnswers();
    }
	
	@GetMapping("/answers/{id}")
	public Optional<Answer> getAnswer(@PathVariable long id){
		return answerService.getAnswer(id);
	}
	
	@PostMapping("/answers/addAnswer")
	public Answer saveAnswer(@RequestBody Answer answer){
		return answerService.saveAnswer(answer);
	}
	
	@GetMapping("/teamSuccess/{idExercise}/{idTeam}")
	public Boolean getSuccessTeamExercise(@PathVariable long idTeam, @PathVariable long idExercise){
		return answerService.getSuccessTeamExercise(idTeam, idExercise);
	}
	
	@GetMapping("/roomSuccess/{idRoom}/{idExercise}")
	public Boolean getSuccessExercise(@PathVariable long idExercise, @PathVariable long idRoom){
		return answerService.getSuccessExercise(idExercise, idRoom);
	}
	
	@GetMapping("/roomExerciseAnswers/{idRoom}/{idExercise}")
	public Iterable<Answer> getRoomExerciseAnswer(@PathVariable long idRoom, @PathVariable long idExercise){
		return answerService.getRoomExerciseAnswers(idRoom, idExercise);
	}
	
	@DeleteMapping("/deleteAnswer/{id}")
	public void deleteAnswer(@PathVariable long id){
		answerService.deleteAnswer(id);
	}
	

}
