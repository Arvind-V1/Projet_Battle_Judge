package com.esiee.BattleCodeAPI.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.esiee.BattleCodeAPI.model.User;
import com.esiee.BattleCodeAPI.repository.UserRepository;

import lombok.Data;

@Data
@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public Optional<User> getUser(final Long id) {
        return userRepository.findById(id);
    }

    public Iterable<User> getUsers() {
        return userRepository.findAll();
    }

    public void deleteUser(final Long id) {
        userRepository.deleteById(id);
    }

    public User saveUser(User user) {
        User savedUser = userRepository.save(user);
        return savedUser;
    }

    public Iterable<User> getTeamUsers(long idTeam){
        return userRepository.getTeamUsers(idTeam);
    }

    public User getUserByMail(String mail){
        return userRepository.getUserByMail(mail).iterator().next();
    }

    public Boolean isMailExistant(String mail){
        return userRepository.isMailExistant(mail) != 0;
    }

    public Optional<User> findUserByMail(String mail){
        return userRepository.findUserByMail(mail);
    }

    public Optional<User> findUserByName(String name){
        return userRepository.findUserByName(name);
    }

    public Optional<User> findUserByMailConnection(String mail, String password){
        return userRepository.findUserByMailConnection(mail, password);
    }

}
