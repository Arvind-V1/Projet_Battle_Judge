package com.esiee.BattleCodeAPI.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.esiee.BattleCodeAPI.model.Answer;
import com.esiee.BattleCodeAPI.repository.AnswerRepository;

import lombok.Data;

@Data
@Service
public class AnswerService {

    @Autowired
    private AnswerRepository answerRepository;

    public Optional<Answer> getAnswer(final Long id) {
        return answerRepository.findById(id);
    }

    public Iterable<Answer> getAnswers() {
        return answerRepository.findAll();
    }

    public void deleteAnswer(final Long id) {
        answerRepository.deleteById(id);
    }

    public Answer saveAnswer(Answer answer) {
        Answer savedAnswer = answerRepository.save(answer);
        return savedAnswer;
    }
	
	public Boolean getSuccessTeamExercise(long idTeam, long idExercise){
		int count = answerRepository.getSuccessTeamExercise(idTeam, idExercise);
		return count != 0;
	}
	
	public Boolean getSuccessExercise(long idExercise, long idRoom){
		int count = answerRepository.getSuccessExercise(idExercise, idRoom);
		return count != 0;
	}
	
	public Iterable<Answer> getRoomExerciseAnswers(long idRoom, long idExercise){
		return answerRepository.getRoomExerciseAnswers(idRoom, idExercise);
	}

}
