package com.esiee.BattleCodeAPI.controller;

import java.util.Optional;

import com.esiee.BattleCodeAPI.model.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.esiee.BattleCodeAPI.model.Room;
import com.esiee.BattleCodeAPI.service.RoomService;

@RestController
public class RoomController {

    @Autowired
    private RoomService roomService;

    /**
    * Read - Get all rooms
    * @return - An Iterable object of Room full filled
    */
    @GetMapping("/rooms")
    public Iterable<Room> getRooms() {
        return roomService.getRooms();
    }
	
	@GetMapping("/rooms/{id}")
	public Optional<Room> getRoom(@PathVariable long id){
		return roomService.getRoom(id);
	}
	
	@GetMapping("/rooms/open")
	public Iterable<Room> getOpenRooms(){
		return roomService.getOpenRooms();
	}

	@PostMapping("/rooms/addRoom")
	public Room saveRoom(@RequestBody Room room){
		return roomService.saveRoom(room);
	}
	
	@PostMapping("/roomExercise/{idRoom}/{idExercise}")
	public void addRoomExercise(@PathVariable long idRoom, @PathVariable long idExercise){
		roomService.addRoomExercise(idRoom, idExercise);
	}
	
	@DeleteMapping("/deleteRoom/{id}")
	public void deleteRoom(@PathVariable long id){
		roomService.deleteRoom(id);
	}
	
	@DeleteMapping("/roomExercise/{idRoom}/{idExercise}")
	public void deleteRoomExercise(@PathVariable long idRoom, @PathVariable long idExercise){
		roomService.deleteRoomExercise(idRoom, idExercise);
	}

	@GetMapping("/rooms/{idRoom}/exercise/{idExercise}")
	public Boolean isExerciseInRoom(@PathVariable("idRoom") long idRoom, @PathVariable("idExercise") long idExercise){
		return roomService.isExerciseInRoom(idRoom, idExercise);
	}

}
