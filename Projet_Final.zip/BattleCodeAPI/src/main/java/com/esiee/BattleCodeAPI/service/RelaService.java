package com.esiee.BattleCodeAPI.service;

import java.util.Optional;
import java.util.Iterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.esiee.BattleCodeAPI.model.Rela;
import com.esiee.BattleCodeAPI.repository.RelaRepository;

import lombok.Data;

@Data
@Service
public class RelaService {

    @Autowired
    private RelaRepository relaRepository;

    public Optional<Rela> getRela(final Long id) {
        return relaRepository.findById(id);
    }

    public Iterable<Rela> getRelas() {
        return relaRepository.findAll();
    }

    public Iterable<Rela> getRelaId(final Long idRoom, final Long idExercise) {
		return relaRepository.getRelaByIds(idRoom, idExercise);
    }
	
	public void deleteById(final long id){
		relaRepository.deleteById(id);
	}

    public Rela saveRela(Rela rela) {
        Rela savedRela = relaRepository.save(rela);
        return savedRela;
    }

}
