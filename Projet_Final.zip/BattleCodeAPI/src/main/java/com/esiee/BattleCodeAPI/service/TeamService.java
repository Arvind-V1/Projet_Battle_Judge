package com.esiee.BattleCodeAPI.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.esiee.BattleCodeAPI.model.Team;
import com.esiee.BattleCodeAPI.repository.TeamRepository;

import lombok.Data;

@Data
@Service
public class TeamService {

    @Autowired
    private TeamRepository teamRepository;

    public Optional<Team> getTeam(final Long id) {
        return teamRepository.findById(id);
    }

    public Iterable<Team> getTeams() {
        return teamRepository.findAll();
    }

    public void deleteTeam(final Long id) {
        teamRepository.deleteById(id);
    }

    public Team saveTeam(Team team) {
        Team savedTeam = teamRepository.save(team);
        return savedTeam;
    }
	
	public Iterable<Team> getRoomTeams(final long idRoom){
		return teamRepository.getRoomTeams(idRoom);
	}
	

}
