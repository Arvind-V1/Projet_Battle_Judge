package com.esiee.BattleCodeAPI.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.esiee.BattleCodeAPI.model.Exercise;

@Repository
public interface ExerciseRepository extends CrudRepository<Exercise, Long> {
	
	@Query(value = "SELECT exercise.id,exercise.title,exercise.text,exercise.answer,exercise.reward FROM exercise inner join relaexerciseroom on exercise.id = idExercise inner join room on room.id = idRoom where idRoom = :idRoom", nativeQuery = true)
	public Iterable<Exercise> getRoomExercises(@Param("idRoom") long idRoom);
	
	@Query(value = "Select * from exercise except SELECT exercise.id,exercise.title,exercise.text,exercise.answer,exercise.reward FROM exercise inner join relaexerciseroom on exercise.id = idExercise inner join room on room.id = idRoom where idRoom = :idRoom", nativeQuery = true)
	public Iterable<Exercise> getRoomNotExercises(@Param("idRoom") long idRoom);
}
