package com.esiee.BattleCodeAPI.controller;

import java.util.Optional;

import com.esiee.BattleCodeAPI.model.Team;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.esiee.BattleCodeAPI.model.User;
import com.esiee.BattleCodeAPI.service.UserService;

@RestController
public class UserController {

    @Autowired
    private UserService userService;

    /**
    * Read - Get all users
    * @return - An Iterable object of User full filled
    */
    @GetMapping("/users")
    public Iterable<User> getUsers() {
        return userService.getUsers();
    }
	
	@GetMapping("/users/{id}")
	public Optional<User> getUser(@PathVariable long id){
		return userService.getUser(id);
	}

	@PostMapping("/users/addUser")
	public User saveUser(@RequestBody User user){
		return userService.saveUser(user);
	}
	
	@GetMapping("/teamUsers/{idTeam}")
	public Iterable<User> getTeamUsers(@PathVariable long idTeam){
		return userService.getTeamUsers(idTeam);
	}

	@GetMapping("/users/mail/{mail}")
	public User getUserByMail(@PathVariable String mail) {
		return userService.getUserByMail(mail);
	}
	
	@DeleteMapping("/deleteUser/{id}")
	public void deleteUser(@PathVariable long id){
		userService.deleteUser(id);
	}

	@GetMapping("/users/mailexists/{mail}")
	public Boolean isMailExistant(@PathVariable String mail) {
		return userService.isMailExistant(mail);
	}

	@GetMapping("/finduserbymail/{mail}")
	public Optional<User> findUserByMail(@PathVariable("mail") String mail){
		return userService.findUserByMail(mail);
	}

	@GetMapping("/finduserbyname/{name}")
	public Optional<User> findUserByName(@PathVariable("name") String name){
		return userService.findUserByName(name);
	}

	@GetMapping("/finduserbymailconnection/{mail}/{password}")
	public Optional<User> findUserByMailConnection(@PathVariable("mail") String mail, @PathVariable("password") String password){
		return userService.findUserByMailConnection(mail, password);
	}

}
