package com.esiee.BattleCodeAPI.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.esiee.BattleCodeAPI.model.Rela;

@Repository
public interface RelaRepository extends CrudRepository<Rela, Long> {
	
	@Query(value = "select * from relaexerciseroom where idroom=:idRoom and idexercise=:idExercise", nativeQuery = true)
	public Iterable<Rela> getRelaByIds(@Param("idRoom") long idRoom, @Param("idExercise") long idExercise);
	
}
