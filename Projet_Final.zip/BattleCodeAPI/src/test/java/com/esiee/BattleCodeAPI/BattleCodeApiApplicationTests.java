package com.esiee.BattleCodeAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BattleCodeApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
